"""Bounded known-control and public metadata access; no unknown target scan."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import io
import json
import time

import numpy as np
import requests
from astropy.io import fits

BASE = Path(__file__).resolve().parent
ROOT = BASE / "20260905_rubin_access"
ROOT.mkdir(exist_ok=False)
PLAN = [
    ("alerce_client_notebook", "https://raw.githubusercontent.com/alercebroker/usecases/master/notebooks/LSST/ALeRCE_LSST_Client_Queries.ipynb", {}),
    ("alerce_tables_notebook", "https://raw.githubusercontent.com/alercebroker/usecases/master/notebooks/LSST/ALeRCE_LSST_Tables.ipynb", {}),
    ("alerce_tap_schema", "https://tap.alerce.online/tap/sync", {"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "json", "QUERY": "SELECT table_name,column_name,datatype FROM TAP_SCHEMA.columns WHERE table_name LIKE 'alerce_tap.%'", "MAXREC": 10000}),
]
for label in ("VW_Hyi", "OY_Car"):
    resolved = json.loads((BASE / "20260905_rubin_metadata" / (label + "_resolver.response")).read_bytes())[0]
    PLAN.append((label + "_cone", "https://api.lsst.fink-portal.org/api/v1/conesearch", {"ra": resolved["jradeg"], "dec": resolved["jdedeg"], "radius": 3, "n": 5, "kind": "across", "columns": "r:diaObjectId,r:midpointMjdTai,f:firstDiaSourceMjdTaiFink"}))
source_id = str(json.loads((BASE / "20260905_rubin_metadata" / "tns_uqf_sources.response").read_bytes())[0]["r:diaSourceId"])
for kind in ("Science", "Template", "Difference"):
    PLAN.append(("tns_uqf_" + kind.lower(), "https://api.lsst.fink-portal.org/api/v1/cutouts", {"diaSourceId": source_id, "kind": kind, "output-format": "FITS"}))
source = Path(__file__).read_bytes()
(ROOT / "executed.py").write_bytes(source)
(ROOT / "contract.json").write_text(json.dumps({"created_at_utc": datetime.now(timezone.utc).isoformat(), "plan": PLAN, "max_requests": len(PLAN), "script_sha256": hashlib.sha256(source).hexdigest(), "retries": 0, "connect_timeout": 10, "read_timeout": 30}, indent=2))
results = []
with requests.Session() as client:
    client.headers["User-Agent"] = "astronomy-portfolio-research/0.1 (read-only public controls)"
    for label, url, params in PLAN:
        entry = {"label": label, "started_at_utc": datetime.now(timezone.utc).isoformat()}
        start = time.monotonic()
        try:
            response = client.get(url, params=params, timeout=(10, 30), allow_redirects=False)
            raw = response.content
            (ROOT / (label + ".response")).write_bytes(raw)
            entry.update(status=response.status_code, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            if response.status_code == 200:
                if params.get("output-format") == "FITS":
                    with fits.open(io.BytesIO(raw)) as hdul:
                        entry["image_planes"] = [{"name": h.name, "shape": list(h.data.shape), "finite_fraction": float(np.isfinite(h.data).mean())} for h in hdul if h.data is not None]
                else:
                    try:
                        body = response.json()
                        if isinstance(body, list):
                            entry["rows"] = len(body)
                        elif isinstance(body, dict):
                            entry["top_level_keys"] = sorted(body)
                            if isinstance(body.get("data"), list):
                                entry["rows"] = len(body["data"])
                    except ValueError:
                        entry["format"] = "not_json"
        except (requests.RequestException, OSError, ValueError) as error:
            entry["error"] = type(error).__name__
        entry["seconds"] = round(time.monotonic() - start, 3)
        results.append(entry)
        (ROOT / "results.json").write_text(json.dumps(results, indent=2))
        print(json.dumps(entry), flush=True)
manifest = {"files": [{"name": p.name, "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.iterdir()) if p.is_file()]}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2))
print("manifest_sha256=" + hashlib.sha256((ROOT / "manifest.json").read_bytes()).hexdigest())
