"""Eight finite TAP GETs: public named controls and two ZTF aggregate probes."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import time

import requests

BASE = Path(__file__).resolve().parent
ROOT = BASE / "20260905_rubin_tap"
ROOT.mkdir(exist_ok=False)
IDS = "170644228968284415,170635501063110696,313761043604045880"
PLAN = [
    ("known_objects", f"SELECT oid,sid,n_det,n_forced,firstmjd,lastmjd FROM alerce_tap.object WHERE sid=1 AND oid IN ({IDS})", 10),
    ("known_detections", f"SELECT d.oid,d.measurement_id,d.mjd,d.band,l.psfflux,l.psffluxerr FROM alerce_tap.detection AS d JOIN alerce_tap.lsst_detection AS l ON d.oid=l.oid AND d.sid=l.sid AND d.measurement_id=l.measurement_id WHERE d.sid=1 AND d.oid IN ({IDS})", 3000),
    ("known_forced", f"SELECT d.oid,d.measurement_id,d.mjd,d.band,l.psfflux,l.psffluxerr FROM alerce_tap.forced_photometry AS d JOIN alerce_tap.lsst_forced_photometry AS l ON d.oid=l.oid AND d.sid=l.sid AND d.measurement_id=l.measurement_id WHERE d.sid=1 AND d.oid IN ({IDS})", 3000),
    ("lsst_bands", "SELECT * FROM alerce_tap.band WHERE sid=1", 20),
]
for label in ("VW_Hyi", "OY_Car"):
    resolved = json.loads((BASE / "20260905_rubin_metadata" / (label + "_resolver.response")).read_bytes())[0]
    ra, dec = resolved["jradeg"], resolved["jdedeg"]
    PLAN.append((label + "_count", f"SELECT COUNT(*) AS n FROM alerce_tap.object WHERE sid=1 AND 1=CONTAINS(POINT('ICRS',meanra,meandec),CIRCLE('ICRS',{ra},{dec},0.0008333333333333334))", 1))
now = datetime.now(timezone.utc)
upper = now.timestamp() / 86400 + 40587
condition = f"ndet>=2 AND lastmjd>=61285 AND lastmjd<={upper}"
PLAN.extend([
    ("ztf_lastmjd_count", f"SELECT COUNT(*) AS n FROM ztf.object WHERE {condition}", 1),
    ("ztf_lastmjd_top1", f"SELECT TOP 1 lastmjd FROM ztf.object WHERE {condition} ORDER BY lastmjd DESC", 1),
])
source = Path(__file__).read_bytes()
(ROOT / "executed.py").write_bytes(source)
(ROOT / "contract.json").write_text(json.dumps({"created_at_utc": now.isoformat(), "plan": PLAN, "max_requests": len(PLAN), "script_sha256": hashlib.sha256(source).hexdigest(), "retries": 0, "connect_timeout": 10, "read_timeout": 30}, indent=2))
results = []
with requests.Session() as client:
    client.headers["User-Agent"] = "astronomy-portfolio-research/0.1 (read-only public controls)"
    for label, query, cap in PLAN:
        entry = {"label": label, "started_at_utc": datetime.now(timezone.utc).isoformat()}
        start = time.monotonic()
        try:
            response = client.get("https://tap.alerce.online/tap/sync", params={"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "json", "QUERY": query, "MAXREC": cap}, timeout=(10, 30), allow_redirects=False)
            raw = response.content
            (ROOT / (label + ".response")).write_bytes(raw)
            entry.update(status=response.status_code, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            if response.status_code == 200:
                body = response.json()
                if isinstance(body, dict) and isinstance(body.get("data"), list):
                    entry["rows"] = len(body["data"])
                    entry["columns"] = [column["name"] for column in body["columns"]]
                    if label.endswith("_count") and len(body["data"]) == 1:
                        entry["reported_count"] = body["data"][0][0]
                    if label == "known_objects":
                        entry["sum_n_det"] = sum(row[2] for row in body["data"])
                        entry["sum_n_forced"] = sum(row[3] for row in body["data"])
                else:
                    entry["error"] = "unexpected_shape"
        except (requests.RequestException, ValueError) as error:
            entry["error"] = type(error).__name__
        entry["seconds"] = round(time.monotonic() - start, 3)
        results.append(entry)
        (ROOT / "results.json").write_text(json.dumps(results, indent=2))
        print(json.dumps(entry), flush=True)
manifest = {"files": [{"name": p.name, "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.iterdir()) if p.is_file()]}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2))
print("manifest_sha256=" + hashlib.sha256((ROOT / "manifest.json").read_bytes()).hexdigest())
