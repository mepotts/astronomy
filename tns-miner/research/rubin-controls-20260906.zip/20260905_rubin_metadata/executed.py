"""Finite metadata and already-public Rubin control retrieval, no unknown scan."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import time

import requests

ROOT = Path(__file__).resolve().parent / "20260905_rubin_metadata"
ROOT.mkdir(exist_ok=False)
PLAN = [
    ("fink_schema", "https://api.lsst.fink-portal.org/swagger.json", {}),
    ("alerce_openapi", "https://api.alerce.online/openapi.json", {}),
    ("alerce_client_conf", "https://raw.githubusercontent.com/alercebroker/alerce_client/main/alerce/conf.py", {}),
    ("alerce_client_common", "https://raw.githubusercontent.com/alercebroker/alerce_client/main/alerce/_common.py", {}),
    ("alerce_tap_capabilities", "https://tap.alerce.online/tap/capabilities", {}),
]
for name, oid in [("tns_uqf", "170644228968284415"), ("tns_spb", "170635501063110696"), ("fink_documented", "313761043604045880")]:
    PLAN.append((name + "_sources", "https://api.lsst.fink-portal.org/api/v1/sources", {"diaObjectId": oid, "columns": "r:diaObjectId,r:diaSourceId,r:midpointMjdTai,r:psfFlux,r:psfFluxErr,r:band"}))
    PLAN.append((name + "_fp", "https://api.lsst.fink-portal.org/api/v1/fp", {"diaObjectId": oid, "columns": "r:diaObjectId,r:midpointMjdTai,r:psfFlux,r:psfFluxErr,r:band"}))
for name in ("VW Hyi", "OY Car"):
    PLAN.append((name.replace(" ", "_") + "_resolver", "https://api.lsst.fink-portal.org/api/v1/resolver", {"resolver": "simbad", "name_or_id": name, "reverse": "true", "nmax": 5}))
source = Path(__file__).read_bytes()
(ROOT / "executed.py").write_bytes(source)
(ROOT / "contract.json").write_text(json.dumps({"created_at_utc": datetime.now(timezone.utc).isoformat(), "plan": PLAN, "max_requests": len(PLAN), "script_sha256": hashlib.sha256(source).hexdigest(), "retries": 0, "connect_timeout": 10, "read_timeout": 30}, indent=2))
results = []
with requests.Session() as client:
    client.headers["User-Agent"] = "astronomy-portfolio-research/0.1 (read-only public controls)"
    for label, url, params in PLAN:
        entry = {"label": label, "started_at_utc": datetime.now(timezone.utc).isoformat()}
        start = time.monotonic()
        try:
            response = client.get(url, params=params, timeout=(10, 30), allow_redirects=False)
            raw = response.content
            (ROOT / (label + ".response")).write_bytes(raw)
            entry.update(status=response.status_code, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            if response.status_code == 200:
                try:
                    body = response.json()
                    if isinstance(body, list):
                        entry["rows"] = len(body)
                        entry["columns"] = sorted(body[0]) if body and isinstance(body[0], dict) else []
                    elif isinstance(body, dict):
                        entry["top_level_keys"] = sorted(body)
                except ValueError:
                    entry["format"] = "not_json"
        except requests.RequestException as error:
            entry["error"] = type(error).__name__
        entry["seconds"] = round(time.monotonic() - start, 3)
        results.append(entry)
        (ROOT / "results.json").write_text(json.dumps(results, indent=2))
        print(json.dumps(entry), flush=True)
manifest = {"files": [{"name": p.name, "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.iterdir()) if p.is_file()]}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2))
print("manifest_sha256=" + hashlib.sha256((ROOT / "manifest.json").read_bytes()).hexdigest())
